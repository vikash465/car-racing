import pygame
from pygame import mixer
import random
import math

carhorn = 0
z = .1
x = 0
pygame.init()
# create the screen
screen = pygame.display.set_mode((800, 600))
# Create background
background = pygame.image.load('background.png')
# Background sound
bgs = mixer.music.load('backgroundsound.wav')
mixer.music.play(-1)
# create Title and icon
pygame.display.set_caption("Car driving")
icon = pygame.image.load('archery.png')
pygame.display.set_icon(icon)
# Car
playerImg = pygame.image.load('car.png')
playerx = 370
playery = 480
playerx_change = 0
playery_change = 0
# Object
treeimg = []
targetImg = []
targetx = []
targety = []
targetx_change = []
targety_change = []
num_of_target = 2
l = 40
tpx = 245
tpy = 430
for i in range(num_of_target):
    targetImg.append(pygame.image.load('target.png'))
    targetx.append(random.randint(tpx, tpy))
    targety.append(l)
    targetx_change.append(z)
    targety_change.append(0)
    l += 250
    tpx += 0
    tpy += 128


arrowImg = pygame.image.load('arrow.png')
arrowx = 0
arrowy = 416
arrowx_change = 0
arrowy_change = 2
arrow_state = "ready"

# Score
score_value = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textx = 10
texty = 10
# Level
level_value = 0
level_font = pygame.font.Font('freesansbold.ttf', 32)
level_textx = 350
level_texty = 10

# Game over text
over_font = pygame.font.Font('freesansbold.ttf', 64)
# window slide
backx = 0
backvelo = 0
backy = 0


def show_score(x, y):
    score = font.render("score : " + str(score_value), True, (0, 0, 255))
    screen.blit(score, (x, y))


def show_level_score(x, y):
    level_score = font.render("Level : " + str(level_value), True, (0, 255, 255))
    screen.blit(level_score, (x, y))


def game_over_text():
    over_text = over_font.render("Game Over", True, (255, 0, 0))
    screen.blit(over_text, (210, 220))


def player(x, y):
    screen.blit(playerImg, (x, y))


def target(x, y, i):
    screen.blit(targetImg[i], (x, y))


def Aim_arrow(x, y):
    global arrow_state
    arrow_state = "Aim"
    screen.blit(arrowImg, (x, y))


def isembeded(targetx, targety, playerx, playery):
    distance = math.sqrt(
        (math.pow((targetx + 64) - (playerx + 64), 2)) + (math.pow((targety + 64) - (playery + 64), 2)))
    if distance < 60:
        return True
    else:
        return False


# game loop
Running = True
while Running:
    # RGB-RED,GREEN,BLUE
    screen.fill((0, 0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
        # Keystroke(Left or Right)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerx_change = -5
            if event.key == pygame.K_RIGHT:
                playerx_change = 5
            if event.key == pygame.K_SPACE:
                for i in range(num_of_target):
                    targety_change[i] = 2
                backvelo = 10
                T += 5

            if event.key == pygame.K_e:
                carhorn = 1

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerx_change = 0
            if event.key == pygame.K_SPACE:
                for i in range(num_of_target):
                    targety_change[i] = 0
                backvelo = 0

            if event.key == pygame.K_e:
                carhorn = 0

    # Background image
    if backy == 600:
        score_value += 5
        for k in range(1, 100):
            if (score_value == 10 * k):
                level_value += 1
                # Level Speed
                z += 0.05
        backy = 0
    backy += backvelo
    screen.blit(background, (backx, backy))
    screen.blit(background, (backx, backy - 600))
    # tree
    S = 100
    T = 400
    for i in range(num_of_target):
        treeimg.append(pygame.image.load('tree.png'))
        screen.blit(treeimg[i], (S, T))
        S += 450
        T -= 300
    # House
    houseimg = pygame.image.load('house.png')
    screen.blit(houseimg, (5, 30))
    homeimg = pygame.image.load('home.png')
    screen.blit(homeimg, (550, 300))
    # Player Movement
    playerx += playerx_change
    if playerx <= 245:
        playerx = 245
    elif playerx >= 445:
        playerx = 445
    for i in range(num_of_target):
        if targety[i] == 600:
            targety[i] = -300

    # Target movement
    for i in range(num_of_target):
        targetx[i] += targetx_change[i]
        targety[i] += targety_change[i]

        if targetx[i] <= 245:
            targetx_change[i] = z

        elif targetx[i] >= 430:
            targetx_change[i] = -z

        # collision
        embeded = isembeded(targetx[i], targety[i], playerx, playery)
        if embeded:
            # Collision sound
            embeded_sound = mixer.Sound('gameoversound.wav')
            embeded_sound.play()
            x = 5

        target(targetx[i], targety[i], i)
        # Arrow movement
        # Game Over
        if arrowy < 1:
            for j in range(num_of_target):
                targety[j] = 2000
            x = 5

    if arrowy <= 0:
        arrowy = 440
        arrow_state = "ready"
    if arrow_state is "Aim":
        Aim_arrow(arrowx, arrowy)
        arrowy -= arrowy_change
    if (x == 5):
        # game over sound
        game_over_sound = mixer.Sound('gameoversound.wav')
        game_over_sound.play()
        mixer.music.stop()
        for j in range(num_of_target):
            targety[j] = 2000
        game_over_text()
    if carhorn == 1:
        car_horn = mixer.Sound('horn.wav')
        car_horn.play()

    player(playerx, playery)
    show_score(textx, texty)
    show_level_score(level_textx, level_texty)
    pygame.display.update()
pygame.quit()
quit()
